const annotationsNoDiggity = [{
  "generation": 1983,
  "recognition": 0.5,
  "path": "M 101,-83 A 140.893 140.893 0 0 0 112,63",
  "text": "13-year-olds at moment of No Diggity's release",
  "textOffset": [
    109,
    95
  ]
}, {
  "generation": 1991,
  "recognition": 0.5,
  "path": "M 101,-83 A 140.893 140.893 0 0 0 112,63",
  "text": "5-year-olds at the time of its release still recognize it today",
  "textOffset": [
    109,
    95
  ]
}, {
  "generation": 1996,
  "recognition": 0.5,
  "path": "M 101,-83 A 140.893 140.893 0 0 0 112,63",
  "text": "Born the same year",
  "textOffset": [
    109,
    95
  ]
}]
